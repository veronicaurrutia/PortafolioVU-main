/**
 * Variables de entorno públicas (Expo las inyecta en build time si empiezan con EXPO_PUBLIC_).
 * Nada de esto es secreto: la seguridad real de Firebase está en las reglas de Firestore.
 */
export const env = {
  firebase: {
    apiKey: process.env.EXPO_PUBLIC_FIREBASE_API_KEY ?? '',
    authDomain: process.env.EXPO_PUBLIC_FIREBASE_AUTH_DOMAIN ?? '',
    projectId: process.env.EXPO_PUBLIC_FIREBASE_PROJECT_ID ?? '',
    storageBucket: process.env.EXPO_PUBLIC_FIREBASE_STORAGE_BUCKET ?? '',
    messagingSenderId: process.env.EXPO_PUBLIC_FIREBASE_MESSAGING_SENDER_ID ?? '',
    appId: process.env.EXPO_PUBLIC_FIREBASE_APP_ID ?? '',
  },
  clarityProjectId: process.env.EXPO_PUBLIC_CLARITY_PROJECT_ID ?? '',
  appEnv: process.env.EXPO_PUBLIC_APP_ENV ?? 'development',
} as const;

export const isFirebaseConfigured = Boolean(env.firebase.apiKey && env.firebase.projectId);
